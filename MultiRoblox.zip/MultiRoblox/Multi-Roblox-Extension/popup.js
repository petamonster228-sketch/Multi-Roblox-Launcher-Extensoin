// Roblox game URL – uses the universal Roblox join link
const GAME_URL = "https://www.roblox.com/games/920587237/Adopt-Me";

document.getElementById('launch').addEventListener('click', () => {
  chrome.storage.local.get(['instances'], (res) => {
    let count = (res.instances || 0) + 1;
    chrome.storage.local.set({ instances: count }, () => {
      document.getElementById('counter').textContent = count;
      // Open a new window/tab with the game
      chrome.tabs.create({ url: GAME_URL });
    });
  });
});

// Show current count on popup open
chrome.storage.local.get(['instances'], (res) => {
  document.getElementById('counter').textContent = res.instances || 0;
});